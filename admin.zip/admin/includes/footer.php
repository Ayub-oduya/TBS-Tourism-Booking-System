<div class="copyrights">
	 <p>© 2023 TBS. All Rights Reserved |  <a href="#">TBS</a> </p>
</div>	
